 // This should go into some file like data.js - populating the table header for chassis configurations

 class TableHeaderChassis {
    constructor () {
        this.header = [
            // [headertext, headerslotid]
            ["Available chassis configuration options","gen","output"],
            ["#slots max HDD of all drive slots","max-hdd-slots","input"],
            ["#slots max SSD of all drive slots","max-ssd-slots","input"],
            ["#slots max NVMe of all drive slots","max-nvme-slots","input"],
            ["# max slots for HDD, SSD and NVMe (in sum, in drive slots)","max-all-slots","input"],
            ["# dedicated slots max NVMe (beside SSD or HDD)","max-dedicated-nvme-slots","input"],
            ["#slots for media (in sum)","max-all-media-sum","input"],
            ["#CPU sockets max","max-cpu-sockets","input"],
            ["#cores per CPU max","max-cpu-cores","input"],
            ["max MEM size","max-mem-gb","input"],
            ["#PCI slots max","max-pci-slots","input"],
            ["HDD size 1 in TB","size-hdd-1","input"],
            ["NIC speed per port in Gb/sec","speed-nic-hba","input"],
            ["NVMe type 1 (for data) size in TB","size-nvme-1","input"],
            ["NVMe type 2 (for RGW cache) size in TB","size-nvme-2","input"],
            ["NVMe type 4 (RocksDB Cache for HDD) size in TB","size-nvme-4","input"],
            ["NVMe type 5 (RocksDB Cache for SSD) size in TB","size-nvme-5","input"],
            ["NVMe type 6 (for RGW dedicated index pools) size in TB","size-nvme-6","input"],
            ["SSD size 1 in TB","size-ssd-1","input"],
            ["SSD need NVMe type 3 fronting (#SSD covered by NVMe)","ssd-to-optane","input"],
            ["NVMe (as Optane) size in GB","size-optane-1","input"],
            ["NIC speed (based on switches available)","speed-nic-switch","input"],
            ["Use RGW caching ? (x=yes) - this per config, otherwise the cache device is ignored","use-rgw-caching","checkbox"],
            ["SSD frontend by Optane ?","use-optane-1","checkbox"]
        ]
    }
}


export default TableHeaderChassis;



