class Chassis {
    constructor (
        ChassisItemsDict = [],
        chassisID,
        maxHDDSlots,
        maxSSDSlots,
        maxNVMeSlots,
        maxAllSlots,
        maxDedicatedNVMeSlots,
        maxAllMediaSum,
        maxCpuSockets,
        maxCpuCores,
        
        maxMemGb,
        maxPciSlots,
        sizeHDD1,
        speedNicHba,
        sizeNVMe1,
        sizeNVMe2,
        sizeNVMe4,
        sizeNVMe5,
        sizeNVMe6,
        sizeSSD1,
        ssdToOptane,
        sizeOptane1,
        speedNicSwitch,
        useRGWCaching,
        useOptane1
    ) {

            /// For debugging purposes, this translates the cell names into the 
            /// elements to use. (Not sure I'll need it really)
            // [slotid,elementName]
            this.ChassisItemsDict = [
            ["chassisID","chassisID"],
            ["max-hdd-slots","maxHDDSlots"],
            ["max-ssd-slots","maxSSDSlots"],
            ["max-nvme-slots","maxNVMeSlots"],
            ["max-all-slots","maxAllSlots"],
            ["max-dedicated-nvme-slots","maxDedicatedNVMeSlots"],
            ["max-all-media-sum","maxAllMediaSum"],
            ["max-cpu-sockets","maxCpuSockets"],
            ["max-cpu-cores","maxCpuCores"],
            
            ["max-mem-gb","maxMemGb"],
            ["max-pci-slots","maxPciSlots"],
            ["size-hdd-1","sizeHDD1"],
            ["speed-nic-hba","speedNicHba"],

            ["size-nvme-1","sizeNVMe1"], // for data
            ["size-nvme-2","sizeNVMe2"], // for RGW cache etc.
            ["size-nvme-4","sizeNVMe4"], // for RocksDBcache HDD
            ["size-nvme-5","sizeNVMe5"], // for RocksDBcache SSD
            ["size-nvme-6","sizeNVMe6"], // for RGW index data
            ["size-ssd-1","sizeSSD1"],
            ["ssd-to-optane","ssdToOptane"],
            ["size-optane-1","sizeOptane1"], // NVMe type 3
            ["speed-nic-switch","speedNicSwitch"],
            ["use-rgw-caching","useRGWCaching"],
            ["use-optane-1","useOptane1"]
            
        ]
        
        this.chassisID = 99
        this.maxHDDSlots = 0
        this.maxSSDSlots = 0
        this.maxNVMeSlots = 0
        this.maxAllSlots = 3
        this.maxDedicatedNVMeSlots = 1
        this.maxAllMediaSum = 1
        this.maxCpuSockets = 1
        this.maxCpuCores = 1

        this.maxMemGb = 0
        this.maxPciSlots = 3
        this.sizeHDD1 = 0
        this.speedNicHba = 10000
        this.sizeNVMe1 = 0
        this.sizeNVMe2 = 0
        this.sizeNVMe4 = 0
        this.sizeNVMe5 = 0
        this.sizeNVMe6 = 0
        this.sizeSSD1 = 0
        this.ssdToOptane = 5 // default, should be changed by setting it (for now) - should depend on ratio between used SSD vs NVMe performance difference for small IO and RocksDB WAL
        this.sizeOptane1 = 0
        this.speedNicSwitch = 0
        this.useRGWCaching = false
        this.useOptane1 = false
    }
}


export default Chassis;