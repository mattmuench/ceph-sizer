import GeneralValues from "./GeneralValues.js";
import TableHeaderChassis from "./TableChassisLabels.js";
import TableHeaderResults from "./TableResultsLabels.js";
import TableHeaderWorkloads from "./TableWorkloadsLabels.js";
import Workload from "./Workload.js";
import Chassis from "./Chassis.js";
import SizingConstraints from "./SizingContraints.js";
import DCConfig from "./DCConfig.js"


// create generalSettings object - holds settings for all configurations
const generalSettings = new GeneralValues

//generalSettings.globalDebug = false

// All tables will show this number of configs - global setting (might become configurable eventually)
generalSettings.numberOfConfigsPossible = 8

// SizingConstraints
const sizingConstraints = new SizingConstraints

// DCConfigs => will have an array of those
//const dcConfig = new DCConfig

/** Example for server object configuration 
const server1 = {
    chassis: {
      slots_hdd: 12,
      slots_ssd: 12,
      slots_nvme_only: 2,
    },
    cpu_sockets: 2,
    cpu_max_cores: 32,
    memory_max: 32 * 24,
    nic_slots_max: 4,
    nic_speed_max: 100,
    nvme_wal_size_max: 750,
    nvme_db_size_max: 7.68,
  };
  
  console.log(
    "My server has NVMe exclusive slots:",
    server1.chassis.slots_nvme_only
  );
  server1.chassis.slots_nvme_only = 4;
  console.log(
    "New chassis has more slots for NVMe only:",
    server1.chassis.slots_nvme_only
  );
  */

// create tableHeaderChassis object - populating the table header for chassis configurations
const tableHeaderChassisArray = new TableHeaderChassis
// check array of header
//console.log(tableHeaderChassisArray.header[0][0])
//console.log(tableHeaderChassisArray.header[0][1])
//console.log(tableHeaderChassisArray.header[1][0])
//console.log(tableHeaderChassisArray.header[1][1])
//console.log(`lenght of array tableHeaderChassisArray: ${tableHeaderChassisArray.header.length}`)


//console.log("The generalValues object:", generalSettings)

const readDesiredCapacity = function (documentMain, generalValues) {
    // console.log("Inside convertTib")
   
    //console.log(generalSettings.desiredCapacityInTB)
    //console.log(generalSettings.desiredCapacityInTiB)
    
    const documentElement = documentMain.getElementById("button-capacity-tib")
    
    documentElement.addEventListener("click", (event) => {
        event.preventDefault()
        //console.log("got it")
        const eventTarget = event.target.getAttribute("data-target")
        const inputElement = documentMain.getElementById(`global-capacity-${eventTarget}-input`)
        generalSettings.desiredCapacityInTiB = inputElement.value
        generalSettings.convertTiBIntoTB(generalSettings.desiredCapacityInTiB)
        const targetElement = documentMain.getElementById(eventTarget).querySelector(".value")
        targetElement.textContent = generalSettings.desiredCapacityInTB
        // console.log(`input value ${generalSettings.desiredCapacityInTB}`)
    })
    return 0
}
let successConvertTib = readDesiredCapacity(document,generalSettings)
console.log(`call to convertTib resulted in: ${successConvertTib}`)

    // updateConvertTib.addEventListener("click", (event) => {
    //     console.log("Caught event1")
    //     event.preventDefault()
    //     console.log("Caught event")
    //     const eventTarget = documentMain.target.getAttribute("data-target")
    //     const inputElement = documentMain.getElementById(`capacity-${eventTarget}-input`)
    //     generalSettings.desiredCapacityInTiB = inputElement.value
    //     generalSettings.convertTiBIntoTB(generalSettings.desiredCapacityInTiB)
    //     const targetElement = documentMain.getElementById(eventTarget).querySelector(".value")
    //     targetElement.textContent = inputElement.value
    //     console.log(`input value ${inputElement.value}`)
    // } )
//}
//const mainHTML = document.querySelector(".maincontent")
//mainHTML.append = convertTib(document, generalSettings)

const readDesiredConfigNICs = function (documentMain, generalValues) {
    const documentElement = documentMain.querySelector("button")
}



const documentAddTable = function (documentMain, rowBaseLabel, idLabel, dataRows, columnsDictArray) {
    
    const documentTable = documentMain.createElement("table")
    documentTable.setAttribute("id",`table-${idLabel}`)
    const documentTableBody = documentMain.createElement("tbody");

    //console.log(`list the columnDictArray object: ${columnsDictArray}`)
    const dataColumns = columnsDictArray.header.length
    //console.log(dataColumns)

    // creating all cells
    for (let i = 0; i <= dataRows; i++) {
      // creates a table row
      const row = documentMain.createElement("tr");
      if (i === 0) {
        for (let j = 0; j < dataColumns; j++) {
            // Create a <th> element and a text node, make the text
            // node the contents of the <th>, and put the <th> at
            // the end of the table row
            const cell = documentMain.createElement("th");
            const actualCell = columnsDictArray.header[j][0]
            //console.log(`check row ${j}: ${columnsDictArray.header[j][0]}`)
            //console.log(`check row ${j}: ${columnsDictArray.header[j][1]}`)
            
            cell.setAttribute("id",columnsDictArray.header[j][0])
            const cellText = documentMain.createTextNode(columnsDictArray.header[j][0]);

            cell.appendChild(cellText);
            row.appendChild(cell);
          }
      }
      else { 
        // Heads-up on row numbers: to allow for using 0...n for all IDs, the ID for
        //  the cell ID is derived from the row number but reduced by 1 => the first row
        //  is row=0 but the first entry is ID=0.
        for (let j = 0; j < dataColumns; j++) {
            // Die erste Spalte muss die ID nur haben und den Namen anzeigen.
            // Die weiteren Spalten muessen input fields werden.
            // Create a <td> element and a text node, make the text
            // node the contents of the <td>, and put the <td> at
            // the end of the table row
            const cell = documentMain.createElement("td");
            cell.setAttribute("id",columnsDictArray.header[j][1])
            if (j === 0) {
                const cellText = documentMain.createTextNode(`${rowBaseLabel} ${i}`);
                cell.appendChild(cellText);
                row.appendChild(cell);
            }
            else {
                const cellElement = documentMain.createElement("input")
                cellElement.setAttribute("type","text")
                cellElement.setAttribute("id",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)
                // const cellText = documentMain.createTextNode(`cell in row ${i}, column ${j}`);
                cell.appendChild(cellElement);
                
                // for debugging, show id of cell
                if (generalSettings.globalDebug === true) {
                    const cellLabel = documentMain.createElement("label")
                    cellLabel.setAttribute("for",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)
                    cellLabel.innerHTML = `[${idLabel}-${i-1}-${columnsDictArray.header[j][1]}]`
                    cell.appendChild(cellLabel);
                }
                row.appendChild(cell);  
            }

                       
          
        }
      }
  
      // add the row to the end of the table body
      documentTableBody.appendChild(row);
    }
  
    // put the <tbody> in the <table>
    documentTable.appendChild(documentTableBody);
    // appends <table> into <body>
    documentMain.body.appendChild(documentTable);
    // sets the border attribute of documentTable to '1'
    documentTable.setAttribute("border", "1");
  }

  const documentAddOutputConfigsTable = function (documentMain, rowBaseLabel, idLabel, dataRows, columnsDictArray) {
    
    const documentTable = documentMain.createElement("table")
    documentTable.setAttribute("id",`table-${idLabel}`)
    const documentTableBody = documentMain.createElement("tbody");

    //console.log(`list the columnDictArray object: ${columnsDictArray}`)
    const dataColumns = columnsDictArray.header.length
    //console.log(dataColumns)

    // creating all cells
    for (let i = 0; i <= dataRows; i++) {
      // creates a table row
      const row = documentMain.createElement("tr");
      if (i === 0) {
        for (let j = 0; j < dataColumns; j++) {
            // Create a <th> element and a text node, make the text
            // node the contents of the <th>, and put the <th> at
            // the end of the table row
            const cell = documentMain.createElement("th");
            const actualCell = columnsDictArray.header[j][0]
            //console.log(`check row ${j}: ${columnsDictArray.header[j][0]}`)
            //console.log(`check row ${j}: ${columnsDictArray.header[j][1]}`)
            
            cell.setAttribute("id",columnsDictArray.header[j][0])
            const cellText = documentMain.createTextNode(columnsDictArray.header[j][0]);

            cell.appendChild(cellText);
            row.appendChild(cell);
          }
      }
      else {  
        // Heads-up on row numbers: to allow for using 0...n for  IDs, the ID for
        //  the cell ID is derived from the row number but reduced by 1 => the first row
        //  is row=0 but the first entry is ID=0.
        for (let j = 0; j < dataColumns; j++) {
            // Die erste Spalte muss die ID nur haben und den Namen anzeigen.
            // Die weiteren Spalten muessen input fields werden.
          // Create a <td> element and a text node, make the text
          // node the contents of the <td>, and put the <td> at
          // the end of the table row
          const cell = documentMain.createElement("td");
          // cell.setAttribute("id",columnsDictArray.header[j][1])
          if (j === 0) {
            const cellText = documentMain.createTextNode(`${rowBaseLabel} ${i}`);
            cell.appendChild(cellText);
            row.appendChild(cell);
          }
          else {
            const cellElement = documentMain.createElement("td")
            cellElement.setAttribute("type","text")
            cellElement.setAttribute("id",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)
            // const cellText = documentMain.createTextNode(`cell in row ${i}, column ${j}`);
            const cellText = documentMain.createTextNode(" ");
            cell.appendChild(cellElement);
            
          }
          // for debugging, show id of cell
          if (generalSettings.globalDebug === true) {
            const cellLabel = documentMain.createElement("label")
            cellLabel.setAttribute("for",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)
            cellLabel.innerHTML = `[${idLabel}-${i-1}-${columnsDictArray.header[j][1]}]`
            cell.appendChild(cellLabel);
          }
          row.appendChild(cell);
          
          
        }
      }

      // add the row to the end of the table body
      documentTableBody.appendChild(row);
    }
  
    // put the <tbody> in the <table>
    documentTable.appendChild(documentTableBody);
    // appends <table> into <body>
    documentMain.body.appendChild(documentTable);
    // sets the border attribute of documentTable to '1'
    documentTable.setAttribute("border", "1");
  }


  const documentAddWorkloadsTable = function (documentMain, rowBaseLabel, idLabel, dataRows, columnsDictArray) {
    
    const documentTable = documentMain.createElement("table")
    documentTable.setAttribute("id",`table-${idLabel}`)
    const documentTableBody = documentMain.createElement("tbody");

    //console.log(`list the columnDictArray object: ${columnsDictArray}`)
    const dataColumns = columnsDictArray.header.length
    //console.log(dataColumns)

    // creating all cells
    for (let i = 0; i <= dataRows; i++) {
      // creates a table row
      const row = documentMain.createElement("tr");
      if (i === 0) {
        for (let j = 0; j < dataColumns; j++) {
            // Create a <th> element and a text node, make the text
            // node the contents of the <th>, and put the <th> at
            // the end of the table row
            const cell = documentMain.createElement("th");
            const actualCell = columnsDictArray.header[j][0]
            //console.log(`check row ${j}: ${columnsDictArray.header[j][0]}`)
            //console.log(`check row ${j}: ${columnsDictArray.header[j][1]}`)
            
            cell.setAttribute("id",columnsDictArray.header[j][0])
            const cellText = documentMain.createTextNode(columnsDictArray.header[j][0]);

            cell.appendChild(cellText);
            row.appendChild(cell);
          }
      }
      else {  
        // Heads-up on row numbers: to allow for using 0...n for workload IDs, the ID for
        //  the cell ID is derived from the row number but reduced by 1 => the first row
        //  is row=0 but the first workload is workloadID=0.
        for (let j = 0; j < dataColumns; j++) {
            // The first column must only have the ID and show the name.
            // All other columns will become either input fields (text, radio, check bos)
          // Create a <td> element and a text node, make the text
          // node the contents of the <td>, and put the <td> at
          // the end of the table row
          const cell = documentMain.createElement("td");
          cell.setAttribute("id",columnsDictArray.header[j][1])
          if (j === 0) {
            const cellText = documentMain.createTextNode(`${rowBaseLabel} ${i}`);
            cell.appendChild(cellText);
            row.appendChild(cell);
          }
          else {
            let elementType = columnsDictArray.header[j][2]
            console.log(`switch on element: ${elementType}`)
            switch (elementType) {
                case "input": {
                        const cellElement = documentMain.createElement("input")
                        cellElement.setAttribute("type","text")
                        cellElement.setAttribute("id",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)
                        // const cellText = documentMain.createTextNode(`cell in row ${i}, column ${j}`);
                        cell.appendChild(cellElement);
                    }
                    break;
                case "output": {
                        /// Note: the following (perhaps commented) lines uses the real row number - not the data row number
                        //const cellElement = documentMain.createTextNode(`output-${i}-${columnsDictArray.header[j][1]}`);
                        const cellElement = documentMain.createTextNode(`-`);
                        //cellElement.setAttribute("id",`${idLabel}-${i}-${columnsDictArray.header[j][1]}`)
                        cell.appendChild(cellElement);
                    }
                    break;
                case "radio": {
                        let firstEntry = 0
                        columnsDictArray.header[j][3].forEach( (radioSelector) => {
                        // set the first entry to default selection
                       
                          // console
                            console.log(radioSelector)
                            
                            const cellElement = documentMain.createElement("input")
                            cellElement.setAttribute("type","radio")
                            cellElement.setAttribute("name",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)
                            cellElement.setAttribute("value",`${radioSelector}`)
                            cellElement.setAttribute("id",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}-${radioSelector}`)
                            if (firstEntry === 0) {
                              cellElement.setAttribute("checked",true)
                              firstEntry = false
                            }
                            
                            cell.appendChild(cellElement);
                            // finish this one first before continuing with the label
                            const cellLabel = documentMain.createElement("label")
                            cellLabel.setAttribute("for",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)
                            cellLabel.innerHTML = radioSelector + "<br>"
                            cell.appendChild(cellLabel);
                        })
                        //let selectLabel = document.getElementById(`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)                            
                        
                    }
                    break;
                case "checkbox": {                                              
                    console.log(`Working on checkbox: ${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)    
                    
                    const cellElement = documentMain.createElement("input")
                        cellElement.setAttribute("type","checkbox")
                        //cellElement.setAttribute("name",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)
                        
                        cellElement.setAttribute("id",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)
                        cell.appendChild(cellElement); 
                        //let selectLabel = document.getElementById(`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)                            
                    }
                    break;
                default:
                    console.log(`no valid statement found for ${elementType}`)
            }

            // for debugging, show id of cell
            if (generalSettings.globalDebug === true) {
                const cellLabel = documentMain.createElement("label")
                cellLabel.setAttribute("for",`${idLabel}-${i-1}-${columnsDictArray.header[j][1]}`)
                cellLabel.innerHTML = `[${idLabel}-${i-1}-${columnsDictArray.header[j][1]}]`
                cell.appendChild(cellLabel);
            }
            // apply all document elements
            row.appendChild(cell);
            
            
            
          }
          
        }
      }
  
      // add the row to the end of the table body
      documentTableBody.appendChild(row);
    }
  
    // put the <tbody> in the <table>
    documentTable.appendChild(documentTableBody);
    // appends <table> into <body>
    documentMain.body.appendChild(documentTable);
    // sets the border attribute of documentTable to '1'
    documentTable.setAttribute("border", "1");
  }

  /// CALL TO FUNCTIONS to create tables ///

// Put the Apply chassis changes button before the overview table
const preSectChangeChassisConfigs = document.createElement("p");
const buttonApplyChangesConfigs= document.createElement("button")
buttonApplyChangesConfigs.setAttribute("id","button-apply-changes")
buttonApplyChangesConfigs.textContent = "Apply changes"
//buttonApplyChangedChassisConfigs.setAttribute("class","favorite styled")
preSectChangeChassisConfigs.appendChild(buttonApplyChangesConfigs)
document.body.appendChild(preSectChangeChassisConfigs)

//// THIS was the original creation of Chassis Config input table:  
//// documentAddTable(document,"Config","chassis",generalSettings.numberOfConfigsPossible,tableHeaderChassisArray)
//// THIS is now trying to use the workloads table structure because we have other styles like input and checkbox already
documentAddWorkloadsTable(document,"Config","chassis",generalSettings.numberOfConfigsPossible,tableHeaderChassisArray)


// Put the Apply chassis changes button before the overview table
const interSectChangeChassisConfigs = document.createElement("p");
const buttonApplyChangedChassisConfigs= document.createElement("button")
buttonApplyChangedChassisConfigs.setAttribute("id","button-apply-chassis-changes")
buttonApplyChangedChassisConfigs.textContent = "Apply chassis changes"
//buttonApplyChangedChassisConfigs.setAttribute("class","favorite styled")
interSectChangeChassisConfigs.appendChild(buttonApplyChangedChassisConfigs)
document.body.appendChild(interSectChangeChassisConfigs)

// create tableHeaderChassis object - populating the table header for chassis configurations

// display the table for overview of all resulting configurations for all configs across all DCs
const tableHeaderResultingConfigsArray = new TableHeaderResults
documentAddOutputConfigsTable(document,"Config","resultsoverview",generalSettings.numberOfConfigsPossible,tableHeaderResultingConfigsArray)

// Separate workloads input table from config results overview table
const intersectOverviewConfigFromWorkloads = document.createElement("p");
intersectOverviewConfigFromWorkloads.innerHTML = "<b>Please input the workloads below and when finished with changes hit the Apply changed workloads button below:</b>"
//buttonApplyChangedChassisConfigs.setAttribute("class","favorite styled")
//interSectChangeChassisConfigs.appendChild(buttonApplyChangedChassisConfigs)
document.body.appendChild(intersectOverviewConfigFromWorkloads)


// display the workloads input table
const tableHeaderWorkloadsInputArray = new TableHeaderWorkloads;
documentAddWorkloadsTable(document,"Workload","workload",generalSettings.numberOfConfigsPossible,tableHeaderWorkloadsInputArray)

// Put the Apply workloads changes button before the overview table
const interSectApplyWorkloadChanges = document.createElement("p");
const buttonApplyWorkloadsConfigs= document.createElement("button")
buttonApplyWorkloadsConfigs.setAttribute("id","button-apply-workloads-changes")
buttonApplyWorkloadsConfigs.textContent = "Apply workloads changes"
//buttonApplyWorkloadsConfigs.setAttribute("class","favorite styled")
interSectApplyWorkloadChanges.appendChild(buttonApplyWorkloadsConfigs)
document.body.appendChild(interSectApplyWorkloadChanges)

// display the tables for an individual config across all DCs
let arrayOfConfigsResults = [];
for (let configNum = 0; configNum < generalSettings.numberOfConfigsPossible; configNum++) {
    const tableHeaderResultsPerConfigArray = new TableHeaderResults;
    tableHeaderResultsPerConfigArray.header[0][0] = `Resulting configuration "config "${configNum+1}`
    arrayOfConfigsResults.push(tableHeaderResultsPerConfigArray)
    documentAddOutputConfigsTable(document,"DC ",`results-configNum-${configNum}`,generalSettings.numberOfDCsPossible,tableHeaderResultsPerConfigArray)
}




// create the objects for holding all information
// 1) workloads: initialize also the arrays holding specific information about the DC use - note that the number 
//    of DCs is variable and defined globally in GeneralValues.numberOfConfigsPossible 
const workloadsArray = []
for (let workloadConfig = 0; workloadConfig < generalSettings.numberOfWorkloadsPossible; workloadConfig++) {
  const workloadNew = new Workload
  for (let z=0; z<generalSettings.numberOfWorkloadsPossible; z++) {
    workloadNew.selectorArrayDC[z]=false;
    workloadNew.checkArrayMinServersDC[z]=0;
    workloadNew.workloadItemsDict.forEach((entry) => {
      if (entry[0] == "selector-dc" ) {
        /// Don't need to record the full name :
        ///   entry[2].push(`selector-dc${z}`)
        /// ... but only the numbers - and by the entry can then select and construct the name
        entry[2][z]=z
      }
      //console.log(`workloadsArrayINIT: Working on entry for workloadsDict - check workloadItemsDict: ${workloadNew.workloadItemsDict}`)
      //console.log(`workloadsArrayINIT: "workloads = item", entry is = ${entry}`)
      if (entry[0] == "selector-dc" ) {
        if (generalSettings.globalDebug) {
          console.log(`workloadsArrayINIT: ODD Working on entry for workloadsDict: ${entry[1]}`)
          console.log(`workloadsArrayINIT: #DC entries for workloadsDict: ${entry[2].length}`)
          console.log(`workloadsArrayINIT: actual DC entry for workloadsDict: ${entry[2][z]}`)
        }
      }
    })
  }
  
  //console.log(`This is content of new workloadNew array: ${workloadNew}`)
  //console.log(`This is content of 1. object in workloadNew array: ${workloadNew.workloadItemsDict[0][1]}`)
  //console.log(`This is content of 2. object in workloadNew array: ${workloadNew.workloadItemsDict[1]}`)
  //console.log(`This is length of workloadNew workload names array: ${workloadNew.workloadItemsDict.length}`)
  
  // console.log(`DC name in cell DC4 from workloadNew array: ${workloadNew.workloadItemsDict["selector-dc"]}`)

  console.log(`This is length of workloadNew array: ${Object.keys(workloadNew).length}`)
  workloadNew.workloadID = `${workloadConfig}`
  
  workloadsArray.push(workloadNew)
}
// check content of the array of workloads (just another array)
console.log(`workloadsArray for workloads has content a first for config#: ${workloadsArray[0].workloadID}`)
console.log(`workloadsArray for workloads has content a last for config#: ${workloadsArray[generalSettings.numberOfConfigsPossible-1].workloadID}`)

    // CHECK the external values - perhaps, need to work with an external object or do we return the newObject ?
    for (let workloads = 0; workloads < workloadsArray.length; workloads++) {
      // find all workload characterizing values from cells - go through all items in the object and find the appropriate input cells
      Object.keys(workloadsArray[workloads]).forEach((value) => {
        workloadsArray[workloads].workloadItemsDict.forEach((entry) => {
          // console.log(`applyAllChanges(): Working on entry for workloadsDict - check workloadItemsDict: ${workloadsValues[workloads].workloadItemsDict}`)
          // console.log(`applyAllChanges(): workloads = ${workloads}, entry is = ${entry}`)
          // console.log(`applyAllChanges(): Working on entry for workloadsDict: ${workloadsValues[workloads].workloadItemsDict[entry]}`)
          // console.log(`EXTERNAL-PRE precheck: entry = ${entry}`)
          if (entry[1] == `${value}`) {
            console.log(`EXTERNAL-PRE CHECK workloads: ${workloads} found value ${value}: ${workloadsArray[workloads][entry[1]]}`)
            //console.log(`EXTERNAL-PRE CHECK-A workloads: ${workloads} found value ${value}: ${workloadsArray[workloads].useCase}`)
          }
        })
      })
    }

// 2) chassis: ????????? => initialize also the arrays holding specific information about the DC use - note that the number 
//    of DCs is variable and defined globally in GeneralValues.numberOfConfigsPossible 
const chassisArray = []
for (let chassisConfig = 0; chassisConfig < generalSettings.numberOfConfigsPossible; chassisConfig++) {
  const chassisNew = new Chassis
  /**
   *  Leave the below - for chassis config - unneeded section for future possible use
   * 
  for (let z=0; z<generalSettings.numberOfConfigsPossible; z++) {
    chassisNew.ChassisItemsDict.forEach((entry) => {
      if (entry[0] == "selector-dc" ) {
        /// Don't need to record the full name :
        ///   entry[2].push(`selector-dc${z}`)
        /// ... but only the numbers - and by the entry can then select and construct the name
        entry[2][z]=z
      }
      //console.log(`workloadsArrayINIT: Working on entry for workloadsDict - check workloadItemsDict: ${workloadNew.workloadItemsDict}`)
      //console.log(`workloadsArrayINIT: "workloads = item", entry is = ${entry}`)
      if (generalSettings.globalDebug) {
        if (entry[0] == "selector-dc" ) {
          if (generalSettings.globalDebug) {
            console.log(`workloadsArrayINIT: ODD Working on entry for workloadsDict: ${entry[1]}`)
            console.log(`workloadsArrayINIT: #DC entries for workloadsDict: ${entry[2].length}`)
            console.log(`workloadsArrayINIT: actual DC entry for workloadsDict: ${entry[2][z]}`)
          }
        }
      }
    })
  }
   */
  
  //console.log(`This is content of new workloadNew array: ${workloadNew}`)
  //console.log(`This is content of 1. object in workloadNew array: ${workloadNew.workloadItemsDict[0][1]}`)
  //console.log(`This is content of 2. object in workloadNew array: ${workloadNew.workloadItemsDict[1]}`)
  //console.log(`This is length of workloadNew workload names array: ${workloadNew.workloadItemsDict.length}`)
  
  // console.log(`DC name in cell DC4 from workloadNew array: ${workloadNew.workloadItemsDict["selector-dc"]}`)

  console.log(`This is length of chassisNew array: ${Object.keys(chassisNew).length}`)
  chassisNew.chassisID = `${chassisConfig}`
  
  chassisArray.push(chassisNew)
}
// check content of the array of workloads (just another array)
console.log(`chassisArray for chassis has content a first for config#: ${chassisArray[0].chassisID}`)
console.log(`chassisArray for chassis has content a last for config#: ${chassisArray[generalSettings.numberOfConfigsPossible-1].chassisID}`)

    // CHECK the external values - perhaps, need to work with an external object or do we return the newObject ?
    for (let chassisConfig = 0; chassisConfig < chassisArray.length; chassisConfig++) {
      // find all chassis characterizing values from cells - go through all items in the object and find the appropriate input cells
      Object.keys(chassisArray[chassisConfig]).forEach((value) => {
        chassisArray[chassisConfig].ChassisItemsDict.forEach((entry) => {
          // console.log(`applyAllChanges(): Working on entry for ChassisItemsDict - check ChassisItemsDict: ${chassisArray[workloads].ChassisItemsDict}`)
          // console.log(`applyAllChanges(): workloads = ${workloads}, entry is = ${entry}`)
          // console.log(`applyAllChanges(): Working on entry for ChassisItemsDict: ${chassisArray[workloads].ChassisItemsDict[entry]}`)
          // console.log(`EXTERNAL-PRE precheck: entry = ${entry}`)
          if (entry[1] == `${value}`) {
            console.log(`EXTERNAL-PRE CHECK chassis: ${chassisConfig} found value ${value}: ${chassisArray[chassisConfig][entry[1]]}`)
            //console.log(`EXTERNAL-PRE CHECK-A chassis: ${chassisConfig} found value ${value}: ${chassisArray[chassisConfig].chassisID}`)
          }
        })
      })
    }    


// 3) dcConfigs: ???????? => initialize also the arrays holding specific information about the DC use - note that the number 
//    of DCs is variable and defined globally in GeneralValues.numberOfConfigsPossible 
const dcConfigArray = []
for (let dcConfig = 0; dcConfig < generalSettings.numberOfDCsPossible; dcConfig++) {
  const dcConfigNew = new DCConfig
  //console.log(`This is content of new workloadNew array: ${workloadNew}`)
  //console.log(`This is content of 1. object in workloadNew array: ${workloadNew.workloadItemsDict[0][1]}`)
  //console.log(`This is content of 2. object in workloadNew array: ${workloadNew.workloadItemsDict[1]}`)
  //console.log(`This is length of workloadNew workload names array: ${workloadNew.workloadItemsDict.length}`)
  
  // console.log(`DC name in cell DC4 from workloadNew array: ${workloadNew.workloadItemsDict["selector-dc"]}`)

  console.log(`This is length of chassisNew array: ${Object.keys(dcConfigNew).length}`)
  dcConfigNew.DCID = `${dcConfig}`
  
  dcConfigArray.push(dcConfigNew)
}

//// testing
    // const newtester = new GeneralValues
    // console.log("Checking tester: are all variables displayed ?")
    // var len = Object.keys(newtester).length;
    // console.log(`number of keys defined in newtester: ${len}`)
    // Object.keys(newtester).forEach((value) => {
    //  console.log(`This is a key in object newtester: ${value}`)
    // })


const applyAllChanges = function (documentMain, generalValues, workloadsValues, chassisValues) {
    // read all current values from all input fields
    // Start with actual global values.
    console.log(`applyAllChanges(): workloadsArray passed contains: ${workloadsValues}`)
    console.log(`applyAllChanges(): number of entries in array: ${workloadsValues.length}`)

    // get general settings from header of the page (like similar/different config) -  capacity is set by readDesiredCapacity()
    let rbsSimilarConfig = document.getElementsByName("global-similar-config");
    for (let i=0, iLen=rbsSimilarConfig.length; i<iLen; i++) {
      if (rbsSimilarConfig[i].checked) {
        generalValues.desiredSimilarConfig = rbsSimilarConfig[i].value;
        console.log(`applyAllChanges -- similarConfig(): For General is desiredSimilarConfig is NEW: desiredSimilarConfig=${generalValues.desiredSimilarConfig}`)
        
      }
    }

    ///   start  workloadsArray / chassisArray elements  and then find the associated  entries in the document to read the values from
    ///           Entries are found based on translation table in the respective classes.
    ///           Based on actual array of workloads/configs, per array entry (just one workload/config) lookup all
    ///           elements available in the object (based on classes Workload/Chassis) and look it up in the 
    ///           WorkloadsItemsDict / ChassisItemsDict: first item is the string used for creating the id for the DOM element
    ///           and second is the name of the corresponding element of the class. There might be additional entries, like for
    ///           the automated number of DCs to use.
    /////////
    ///////// Reading in all value for CHASSIS
    /////////
    workloadsValues.forEach((item) => {
      console.log(`applyAllChanges -- workloads(): workloadID = ${item}`)
      Object.keys(item).forEach((value) => {
        item.workloadItemsDict.forEach((entry) => {
          if (generalValues.globalDebug) {
            // console.log(`applyAllChanges() 2: Working on entry for workloadsDict - check workloadItemsDict: ${item.workloadItemsDict}`)
            // console.log(`applyAllChanges() 2: "workloads = item", entry is = ${entry}`)
            console.log(`applyAllChanges() 2: ODD Working on entry for workloadsDict: ${entry[1]}`)
          }
          
          
          if (entry[1] == `${value}`) {
            console.log(`found value: ${value}`)
            const testToConsoleValue = `workloadsValues[item.workloadID].${entry[1]}`
            const testForConsoleValue = workloadsValues[item.workloadID][entry[1]]
            console.log(`For ${item.workloadID} is workloadsValues.item.value is actually ${value}: ${testToConsoleValue}=${testForConsoleValue}`)
            
            
            if (value == "workloadID") {
              // console.log(`applyAllChanges -- workloads(): entry for workloadID ${item}=> skip it`)
            }
            else {
              // constructing the id string for the cell to read from
              let idStringToFind =  `workload-${item.workloadID}-${entry[0]}`
              console.log(`applyAllChanges -- workloads(): looking up the DOM element id ${idStringToFind}`)
              const inputElement = documentMain.getElementById(idStringToFind)
              let myValue;
              let outputSubString = "output-"
              if (entry[0].includes(outputSubString)) {
                console.log(`applyAllChanges -- workloads(): skipping entry[0] for input which is output: ${entry[0]}`)
              }
              else {
                switch (entry[0]) {
                  case "use-case": {
                    let rbs = document.getElementsByName(idStringToFind);
                    for (let i=0, iLen=rbs.length; i<iLen; i++) {
                      if (rbs[i].checked) {
                        workloadsValues[item.workloadID][entry[1]] = rbs[i].value;
                        console.log(`applyAllChanges -- workloads(): For ${item.workloadID} is workloadsValues.item.value is NEW: workloadsValues[${item.workloadID}].${entry[1]}=${workloadsValues[item.workloadID][entry[1]]}`)
                        
                      }
                    }
                    break
                  }
                  case "selector-highdense":
                  case "selector-fullperf": {
                    workloadsValues[item.workloadID][entry[1]]=documentMain.getElementById(idStringToFind).checked
                    console.log(`applyAllChanges -- workloads(): For ${item.workloadID} is workloadsValues.item.value is NEW: workloadsValues[${item.workloadID}].${entry[1]}=${workloadsValues[item.workloadID][entry[1]]}`)                    
                    break
                  }
                  case "selector-dc": {
                    //// Multiple entries to check here - stay here and loop through the registered DCs from 
                    ////   Workload.workloadItemsDict["selector-dc"] in the dcSelectorList
                    for (let dcItem = 0; dcItem < generalSettings.numberOfDCsPossible; dcItem++) {
                      console.log(`applyAllChanges -- workloads(): checking DC selector - ${entry[2][dcItem]}`)
                      
                      
                      let lookupDOMElement = `${idStringToFind}`+`${dcItem}`
                      
                      
                      if (generalValues.globalDebug) {
                        const checkForDOMElement =  documentMain.getElementById(lookupDOMElement)
                        console.log(`applYAllChanges -- workloads(): Is checked ${lookupDOMElement} ? =${checkForDOMElement.checked}`)
                        let resultCheck = checkForDOMElement.checked
                        console.log(`applyAllChanges -- workloads(): checking DC selector NOW - ${entry[2][dcItem]}:${resultCheck}`)
                      }
                      workloadsValues[item.workloadID][entry[1]][dcItem]=documentMain.getElementById(lookupDOMElement).checked
                      console.log(`applyAllChanges -- workloads(): For ${item.workloadID} is workloadsValues.item.value ${dcItem} is NEW: workloadsValues[${item.workloadID}].${entry[1]}[${dcItem}]=${workloadsValues[item.workloadID][entry[1]][dcItem]}`)
                    }
                    
                    }
                    break
                  default:  {
                    myValue = workloadsValues[item.workloadID][entry[1]] = inputElement.value
                    console.log(`For ${item.workloadID} is workloadsValues.item.value is NEW ${value}: ${testToConsoleValue}=${workloadsValues[item.workloadID][entry[1]]}`)
                  }
                }
              }
              console.log(`applyAllChanges -- workloads(): myValue = ${myValue} for idStringToFind=${idStringToFind}`)
               
            }
              
              /// Get value of checked or unchecked from checkboxes 
              // document.querySelector('.messageCheckbox').checked;

             //console.log(`applyAllChanges -- workloads(): myValue = ${myValue} for idStringToFind=${idStringToFind}`)
          }
            
        })
      })
      })

      /////////
      ///////// Reading in all value for CHASSIS
      /////////
      

      chassisValues.forEach((item) => {
        console.log(`applyAllChanges -- chassis(): chassisID = ${item}`)
        Object.keys(item).forEach((value) => {
          item.ChassisItemsDict.forEach((entry) => {
            if (generalValues.globalDebug) {
              // console.log(`applyAllChanges() 2: Working on entry for ChassisItemsDict - check ChassisItemsDict: ${item.ChassisItemsDict}`)
              // console.log(`applyAllChanges() 2: "chassis = item", entry is = ${entry}`)
              console.log(`applyAllChanges() 2: ODD Working on entry for ChassisItemsDict: ${entry[1]}`)
            }
            
            
            if (entry[1] == `${value}`) {
              console.log(`found value: ${value}`)
              const testToConsoleValue = `chassisValues[item.chassisID].${entry[1]}`
              const testForConsoleValue = chassisValues[item.chassisID][entry[1]]
              console.log(`For ${item.chassisID} is chassisValues.item.value is actually ${value}: ${testToConsoleValue}=${testForConsoleValue}`)
              
              
              if (value == "chassisID") {
                // console.log(`applyAllChanges -- workloads(): entry for chassisID ${item}=> skip it`)
              }
              else {
                // constructing the id string for the cell to read from
                let idStringToFind =  `chassis-${item.chassisID}-${entry[0]}`
                console.log(`applyAllChanges -- chassis(): looking up the DOM element id ${idStringToFind}`)
                const inputElement = documentMain.getElementById(idStringToFind)
                let myValue;
                let outputSubString = "output-"
                if (entry[0].includes(outputSubString)) {
                  console.log(`applyAllChanges -- chassis(): skipping entry[0] for input which is output: ${entry[0]}`)
                }
                else {
                  switch (entry[0]) {
                    case "use-case": {
                      let rbs = document.getElementsByName(idStringToFind);
                      for (let i=0, iLen=rbs.length; i<iLen; i++) {
                        if (rbs[i].checked) {
                          chassisValues[item.chassisID][entry[1]] = rbs[i].value;
                          console.log(`applyAllChanges -- chassis(): For ${item.chassisID} is chassisValues.item.value is NEW: chassisValues[${item.chassisID}].${entry[1]}=${chassisValues[item.chassisID][entry[1]]}`)
                          
                        }
                      }
                      break
                    }
                    case "selector-highdense":
                    case "selector-fullperf": {
  
                      workloadsValues[item.chassisID][entry[1]]=documentMain.getElementById(idStringToFind).checked
                      console.log(`applyAllChanges -- chassis(): For ${item.chassisID} is chassisValues.item.value is NEW: chassisValues[${item.chassisID}].${entry[1]}=${chassisValues[item.chassisID][entry[1]]}`)                    
                      break
                    }
                    case "selector-dc": {
                      //// Multiple entries to check here - stay here and loop through the registered DCs from 
                      ////   Chassis.ChassisItemsDict["selector-dc"] in the dcSelectorList
                      for (let dcItem = 0; dcItem < generalSettings.numberOfDCsPossible; dcItem++) {
                        console.log(`applyAllChanges -- chassis(): checking DC selector - ${entry[2][dcItem]}`)
                        
                        
                        let lookupDOMElement = `${idStringToFind}`+`${dcItem}`
                        
                        
                        if (generalValues.globalDebug) {
                          const checkForDOMElement =  documentMain.getElementById(lookupDOMElement)
                          console.log(`applYAllChanges -- chassis(): Is checked ${lookupDOMElement} ? =${checkForDOMElement.checked}`)
                          let resultCheck = checkForDOMElement.checked
                          console.log(`applyAllChanges -- chassis(): checking DC selector NOW - ${entry[2][dcItem]}:${resultCheck}`)
                        }
                        chassisValues[item.chassisID][entry[1]][dcItem]=documentMain.getElementById(lookupDOMElement).checked
                        console.log(`applyAllChanges -- chassis(): For ${item.chassisID} is chassisValues.item.value ${dcItem} is NEW: chassisValues[${item.chassisID}].${entry[1]}[${dcItem}]=${chassisValues[item.chassisID][entry[1]][dcItem]}`)
                      }
                      
                      }
                      break
                    default:  {
                      myValue = chassisValues[item.chassisID][entry[1]] = inputElement.value
                      console.log(`For ${item.chassisID} is chassisValues.item.value is NEW ${value}: ${testToConsoleValue}=${chassisValues[item.chassisID][entry[1]]}`)
                    }
                  }
                }
                console.log(`applyAllChanges -- chassis(): myValue = ${myValue} for idStringToFind=${idStringToFind}`)
                 
              }
                
                /// Get value of checked or unchecked from checkboxes 
                // document.querySelector('.messageCheckbox').checked;
  
               //console.log(`applyAllChanges -- workloads(): myValue = ${myValue} for idStringToFind=${idStringToFind}`)
            }
              
          })
        })
        })
    }

    
    
    /// FINDING ALL ELEMENTS FOR WORKLOADS TABLE ----  ==> table specific work - other way round: 
    ///   start with the DOM elements of the table and then find the associated workload array entries to store it
    /** 
    const tableWorkloadEntries = documentMain.getElementById("table-workload")
    console.log(`applyAllChanges - workloads(): tableWorkloadEntries is ${tableWorkloadEntries}, `)
    tableWorkloadEntries.querySelectorAll("td").forEach((cell) => {
       console.log(`applyAllChanges - workloads(): cell found with id: ${cell.id}`)
    })
    */

    /// FINDING by 
  
    

    /// Perhaps, I would need to use querySelectorAll and then look for any element with global - or just check 
    // the other way round: travel through all possible inputs and look for it from the document (might be better)
    /** 
    const documentElement = documentMain.getElementById("button-capacity-tib")
    
    documentElement.addEventListener("click", (event) => {
        event.preventDefault()
        //console.log("got it")
        const eventTarget = event.target.getAttribute("data-target")
        const inputElement = documentMain.getElementById(`global-capacity-${eventTarget}-input`)
        generalSettings.desiredCapacityInTiB = inputElement.value
        generalSettings.convertTiBIntoTB(generalSettings.desiredCapacityInTiB)
        const targetElement = documentMain.getElementById(eventTarget).querySelector(".value")
        targetElement.textContent = generalSettings.desiredCapacityInTB
        // console.log(`input value ${generalSettings.desiredCapacityInTB}`)
    })
    return 0
    */


//
//
// install EventListeners for Apply Changes buttons
const buttonApplyChanges = function (documentMain, generalValues, workloadsArrayLocal, chassisArrayLocal) {
   
  const clickedApplyChassisChanges = documentMain.getElementById("button-apply-chassis-changes")
  clickedApplyChassisChanges.addEventListener("click", (event) => {
      event.preventDefault()
      //console.log("got it")
      //const eventTarget = event.target.getAttribute("data-target")
      
      // Here, all the magic needs to be started with recalculation of any of the things.
      //const inputElement = documentMain.getElementById(`capacity-${eventTarget}-input`)
      console.log("Recalculation after changes to chasis config should start now")
      applyAllChanges(documentMain, generalValues, workloadsArrayLocal,chassisArrayLocal)
  })
  const clickedApplyCapacityChanges = documentMain.getElementById("button-apply-workloads-changes")
  clickedApplyCapacityChanges.addEventListener("click", (event) => {
      event.preventDefault()
      //console.log("got it")
      //const eventTarget = event.target.getAttribute("data-target")
      
      // Here, all the magic needs to be started with recalculation of any of the things.
      //const inputElement = documentMain.getElementById(`capacity-${eventTarget}-input`)
      console.log("Recalculation after changes to workloads should start now")
      applyAllChanges(documentMain, generalValues, workloadsArrayLocal,chassisArrayLocal)
  })
  const clickedApplyChanges = documentMain.getElementById("button-apply-changes")
  clickedApplyChanges.addEventListener("click", (event) => {
      event.preventDefault()
      //console.log("got it")
      //const eventTarget = event.target.getAttribute("data-target")
      
      // Here, all the magic needs to be started with recalculation of any of the things.
      //const inputElement = documentMain.getElementById(`capacity-${eventTarget}-input`)
      console.log("Recalculation after changes should start now")
      applyAllChanges(documentMain, generalValues, workloadsArrayLocal,chassisArrayLocal)
  })
  console.log(`buttonApplyChanges(): workloadsArray passed contains: ${workloadsArrayLocal}`)
  
  return 0
}
let buttonApplyChangesClicked = buttonApplyChanges(document,generalSettings,workloadsArray,chassisArray)
// installed EventListeners for Apply Changes buttons

    // CHECK the external values - perhaps, need to work with an external object or do we return the newObject ?
    for (let workloads = 0; workloads < workloadsArray.length; workloads++) {
      // find all workload characterizing values from cells - go through all items in the object and find the appropriate input cells
      Object.keys(workloadsArray[workloads]).forEach((value) => {
        workloadsArray[workloads].workloadItemsDict.forEach((entry) => {
          // console.log(`applyAllChanges(): Working on entry for workloadsDict - check workloadItemsDict: ${workloadsValues[workloads].workloadItemsDict}`)
          // console.log(`applyAllChanges(): workloads = ${workloads}, entry is = ${entry}`)
          // console.log(`applyAllChanges(): Working on entry for workloadsDict: ${workloadsValues[workloads].workloadItemsDict[entry]}`)
          // console.log(`EXTERNAL precheck: entry = ${entry}`)
          if (entry[1] == `${value}`) {
            console.log(`EXTERNAL-POST CHECK workloads: ${workloads} found value ${value}: ${workloadsArray[workloads][entry[1]]}`)
          }
        })
      })
    }
    

const calculateDCDistribution = function (generalValues,workloadsArrayLocal,chassisArrayLocal) {
  // From Google Sheet 
}

const workloadsDetermineRocksDBSpace = function (workloadLocal, sizingConstraints) {
  const useCase = workloadLocal.useCase
  sizingConstraints.addCapacityPerPooluse.forEach((useCaseName)=>{
    if (useCaseName[0] == useCase) {
      workloadLocal.rocksDBSpaceInPercent = useCaseName[1]
    }
  })
}

const dcConfigDetermineNumberOfDCsInUse = function (generalValues, workloadsArrayLocal) {
  // cell B41
  let numberOfUsedDCsAllWorkloads = 0
  for ( let dcItem = 0; dcItem < generalValues.numberOfDCsPossible; dcItem++) {
    
    let dcUsedInWorkload = false
    for ( let workloadID = 0; workloadID < generalValues.numberOfWorkloadsPossible; workloadID++) {
      if (workloadsArrayLocal[workloadID].selectorArrayDC[dcItem] === true) {
        dcUsedInWorkload = true
      }
    }
    if (dcUsedInWorkload) {numberOfUsedDCsAllWorkloads++}
    // reset counter to restart for the next DC number
    dcUsedInWorkload = false
    
  }
  generalValuesLocal.numberOfDCsInUse = numberOfUsedDCsAllWorkloads
}

const workloadDetermineCapacityRaw = function (generalValues, workloadsArrayLocal, sizingConstraints) {
  /// Determine the raw capacity, flash raw capacity, and HDD raw capacity needed for each workload and store it there
  for (let workloadItem = 0; workloadItem < generalValues.numberOfWorkloadsPossible; workloadItem++) {
    let localDCCapacityFlash = 0
    let localDCCapacityHDD = 0
    let localGrossCapacity = workloadsArrayLocal[workloadItem].reqCapacityNet * reqNumReplica / sizingConstraints.cephClusterNearFull / workloadsArrayLocal[workloadItem].sumNumberDC
    workloadsArrayLocal[workloadItem].reqCapacityGrossHDD = localGrossCapacity * (1 - workloadsArrayLocal[workloadItem].reqFlashPercent/100)
    workloadsArrayLocal[workloadItem].reqCapacityGrossSSD = localGrossCapacity * workloadsArrayLocal[workloadItem].reqFlashPercent/100
    
  }
}

const dcConfigDetermineCapacityRaw = function (generalValues, workloadsArrayLocal, dcConfigArrayLocal) {

/// THIS might be wrong: the number of DCs in use is not the number of DCs used for a certain workload and thus
/// gives no good sizing for the distribution of workloads and hence capacity across different DCs.

  /// Determine the flash and HDD raw capaciy needed based on shares defined by the number of actually used DCs per workload
  /// an assign the actual needed capacity as sum of all for a DC to dcConfig
  /// Inside the WorkloadsArray[] workload, use the selectorArrayDC to determine wether a workload uses this DC before adding the
  /// capacity to a certain actual DC capacity
  for (let dcItem = 0; dcItem < generalValues.numberOfDCsPossible; dcItem++) {
    let localDCCapacityFlash = 0
    let localDCCapacityHDD = 0
    for (let workloadItem = 0; workloadItem < generalValues.numberOfWorkloadsPossible; workloadItem++) {
      if (workloadsArrayLocal[workloadItem].selectorArrayDC[dcItem] === true) {
        // workload uses this DC
        localDCCapacityFlash += workloadsArrayLocal[workloadItem].reqCapacityGrossSSD / generalValues.numberOfDCsInUse
        localDCCapacityHDD += workloadsArrayLocal[workloadItem].reqCapacityGrossHDD / generalValues.numberOfDCsInUse
      }
    }
    dcConfigArrayLocal[dcItem].capacityNeededForSSD = localDCCapacityFlash
    dcConfigArrayLocal[dcItem].capacityNeededForHDD = localDCCapacityHDD    
  }
}

const dcConfigDetermineNumberOfRoleInstances = function (generalValues, workloadsArrayLocal, sizingConstraints, dcConfigArrayLocal) {
  /// Determine the number of scale-out and special instances needed in this DC - as per number
  for (let dcItem = 0; dcItem < generalValues.numberOfDCsPossible; dcItem++) {
    // all instances for this actual DC:
    let localScaleoutInstances = 0
    let localSpecialInstances = 0
    // crawl through the workloads and figure out the different use cases that would need some kind of instance
    for (let workloadItem = 0; workloadItem < generalValues.numberOfWorkloadsPossible; workloadItem++) {
      let localWorkloadInstances = 0
      // sum up all scale-out instances based on the useCase and the min number of instances for this use case
      // ...., then divide by the number of DCs use for this workload and then determine whether this actual DC is used
      // then add it to the actual counter
      if (workloadsArrayLocal[workloadItem].selectorArrayDC[dcItem] === true) {
        // actual DC is used => add the number of instances 
        switch (workloadsArrayLocal[workloadItem].useCase) {
          // "block","rgwdata","filedata","filemetadata","iscsi"]
          case "block":
            localScaleoutInstances += 0
            break
          case "rgwdata":
            localScaleoutInstances += Math.round(sizingConstraints.minNumberOfInstancesRoleRGW / workloadsArrayLocal[workloadItem].sumNumberDC)
            break
          case "filedata":  
            // filemetadata (it's taking only one set of MDS per workload but filedata ca be multiple for different
            // file systems or sub-trees with separat data (... with perhaps dedicated sets of MDS)
            localScaleoutInstances += Math.round(sizingConstraints.minNumberOfInstancesRoleMDS / workloadsArrayLocal[workloadItem].sumNumberDC)
            break
          case "filemetadata":
            // filemetadata can be only one per file system - all needed instances are already accounted in the filedata section
            localScaleoutInstances += 0
            break
          //
          // Special Instances
          //
          case "iSCSI":
            localSpecialInstances += Math.round(sizingConstraints.minNumberOfInstancesRoleMDS / workloadsArrayLocal[workloadItem].sumNumberDC)
            break
  
          // no default: iSCSI and others might be configured but not counting as scale-out
        }
      }
    }
    dcConfigArrayLocal[dcItem].numberOfLocalScaleoutInstances = localScaleoutInstances
    dcConfigArrayLocal[dcItem].numberOfLocalSpecialInstances = localSpecialInstances
  }
}


const dcConfigDetermineNumberOfMediaRequired = function (generalValues, workloadsArrayLocal, sizingConstraints, dcConfigArrayLocal, chassisArrayLocal, actualChassisID) {
  /**
    This is covering the H41, H42, J41, J42, N41, and O41 (for SSD)
    NOTE: no coverage for NVMe1 use for workloads (yet)
   */
  for (let dcItem = 0; dcItem < generalValues.numberOfDCsPossible; dcItem++) {
    ////////////// HERE HERE HERE IMPORTANT !!! //////// (see description of issue below)
    /// Idea: restructure it by reusing simply the existing function but apply it to the (new) array elements - doesn't need to rewrite
    ///       the function but create a wrapper function to work through the array elements.
    
    /// dcConfig is actual more the ResultsDCConfig => the DCConfig is for an actual configuration only => need to change all the above
    /// 
    

    // Check if RGW workload is running in this actual DC => this determines the number of media required for the index.
    /// Note: by default, the index can be backed by the media that is holding the RocksDB but must be flash media. Those can be used - however, for production,
    /// it might be worth to spend additional media for placing the object index: 
    /// - running out of space might block any side (RocksDB or index) from applying any changes. Quick allocations from RocksDB blueFS can be limiting the space
    /// - fast growing number of objects can limit the space for RocksDB and might render the OSD unusable
    /// - the space is limited for any OSD and cannot be grown once running out of space
    /// - spending any kind of dedicated media would allow to grow the index space independently with additional media
    
   
    let localDCDedicatedObjectIndexCapacity = 0 // raw capacity needed for dedicated index pool in TB
    let localDCNumberOfRGWCacheMedia = 0
    let localDCRequiredIndexCapacityOnNVMe4 = 0  // RocksDB location for HDD
    let localDCRequiredIndexCapacityOnNVMe5 = 0  // RocksDB location for SSD if on separate NVMe
    let localDCCorrectionForUnalignedObjectsHDD = 0  // additional capacity to be take into account for unaligned object payload data allocation on media
    let localDCCorrectionForUnalignedObjectsSSDWithDedicatedNVMe = 0  // additional capacity to be take into account for unaligned object payload data allocation on media
    let localDCCorrectionForUnalignedObjectsSSDWithoutDedicatedNVMe = 0  // additional capacity to be take into account for unaligned object payload data allocation on media
    let localDCCorrectionForUnalignedObjectsNVMe1 = 0  // UNUSED yet: additional capacity to be take into account for unaligned object payload data allocation on media
                                                     // => need to apply further config options for selecting type of flash for the workload
    let localSSDCapacityWithDedicatedRocksDB = 0 // Any flash (portion of the) workload could be configured using the same media or using dedicated RocksDB media - would need different number of media 
    let localSSDCapacityWithoutDedicatedRocksDB = 0 // Any flash (portion of the) workload could be configured using the same media or using dedicated RocksDB media - would need different number of media 
    let localSSDAddCapacityWithOutDedicatedRocksDB = 0 // Any flash (portion of the) workload could be configured using the same media or using dedicated RocksDB media - would need this capacity on separate media

    let localDCRocksDBSizeHDD = 0
    let localDCRocksDBSizeSSDWithDedicatedNVMe = 0
    let localDCRocksDBSizeSSDWithoutDedicatedNVMe = 0
    let localDCRocksDBSizeNVMe1 = 0

    let localNumberOfSSDNeededDedicatedRocksDB = 0
    let localNumberOfSSDNeededNonDedicatedRocksDB = 0

    for (let workloadItem = 0; workloadItem < generalValues.numberOfWorkloadsPossible; workloadItem++) {

      let localDCObjectIndexCapacity = 0 // takes all the actual index capacity required for the workload to be processed into the different locations
      let localWorkloadCorrectionForUnalignedObjectsHDD = 0
      let localWorkloadCorrectionForUnalignedObjectsSSD = 0
      let localWorkloadCorrectionForUnalignedObjectsNVMe1 = 0

      let localWorkloadRocksDBSizeHDD = 0
      let localWorkloadRocksDBSizeSSDWithDedicatedNVMe = 0
      let localWorkloadRocksDBSizeSSDWithoutDedicatedNVMe = 0
      let localWorkloadRocksDBSizeNVMe1 = 0

      // RGW workloads
      if (workloadsArrayLocal[workloadItem].selectorArrayDC[dcItem] === true && workloadsArrayLocal[workloadItem].useCase === "rgwdata" ) {

        // workload uses this DC AND actual workload is an RGW workload
        //  Then check for the size needed and calculate the capacity needed for all workloads.
        // First: how many replica we'll need => if a single DC is used, 3 replica must be accounted for it. For more than a single DC, it depends on the number of
        // replica to be hosted within a single DC. This is different for 2 main DCs (4 replicas required, 2 per main DC) and all configs with more: then 3 replicas.
        //
        // Note: The index for RGW objects is either stored alongside with the pool itself of might use a dedicated pool. In case of the index uses no separate pool, 
        //       the capacity is needed within the RocksDB space. If HDD fronted by flash media then the space is needed there and must be taken into account for sizing
        //       those media for providing appropriate space that doesn't conflict with neither RocksDB nor the raw payload data, in design already.
        //       This additional capacity might go into a dedicated flash pool if configured this way. Otherwise needs to go into the RocksDB flash space.
        //       Flash only portion of a workload will need the capacity on the media for the RocksDB or on the media directly. HDD (hybrid supported only) pools will need
        //       this capacity on RocksDB flash media. However, based on design, also the index might use a dedicated pool for it.
        // Per case, calculate the needed capacity for hosting the index. This is first independent of any assignment to a certain DC. Then divide the resulting individual capacity 
        // by the number of actually used DCs and sum it up for all the workloads.
        /////// switch (workloadsArrayLocal[workloadItem].sumNumberDC) {
        ///////   case 1: // only a single DC in the whole configuration => replica required is 3 => may be tuned with SizingConstraints.requiredNumberOfReplicaForObjectIndex
        ///////     {
        ///////       // index capacity is for the workload - per DC 
        ///////       localRequiredIndexCapacityFlash += workloadsArrayLocal[workloadItem.workload].reqCapacityNet * workloadsArrayLocal[workloadItem].reqFlashPercent / 100 * 1000*1000*1000*1000/(workloadsArrayLocal[workloadItem].sizeAvgObj * 1024) * sizingConstraints.expectedAverageEntrySizeInObjectIndexInBytes / 1024/1024/1024/1024 * workloadsArrayLocal[workloadItem].selectorRGWLifecycleNumVersions *sizingConstraints.requiredNumberOfReplicaForObjectIndex / workloadsArrayLocal[workloadItem].sumNumberDC
        ///////       localRequiredIndexCapacityHDD += workloadsArrayLocal[workloadItem.workload].reqCapacityNet * (100 - workloadsArrayLocal[workloadItem].reqFlashPercent) / 100 * 1000*1000*1000*1000/(workloadsArrayLocal[workloadItem].sizeAvgObj * 1024) * sizingConstraints.expectedAverageEntrySizeInObjectIndexInBytes * workloadsArrayLocal[workloadItem].selectorRGWLifecycleNumVersions *sizingConstraints.requiredNumberOfReplicaForObjectIndex / workloadsArrayLocal[workloadItem].sumNumberDC
        ///////     }
        ///////     break
        ///////   default: // 2 and more main DCs 
        ///////     {
        ///////       // index capacity is for the workload - per DC must be calculated later
        ///////       localRequiredIndexCapacityFlash += workloadsArrayLocal[workloadItem.workload].reqCapacityNet * workloadsArrayLocal[workloadItem].reqFlashPercent / 100 * 1000*1000*1000*1000/(workloadsArrayLocal[workloadItem].sizeAvgObj * 1024) * sizingConstraints.expectedAverageEntrySizeInObjectIndexInBytes * workloadsArrayLocal[workloadItem].selectorRGWLifecycleNumVersions * workloadsArrayLocal[workloadItem].reqNumReplica / workloadsArrayLocal[workloadItem].sumNumberDC
        ///////       localRequiredIndexCapacityHDD = workloadsArrayLocal[workloadItem.workload].reqCapacityNet * (100 - workloadsArrayLocal[workloadItem].reqFlashPercent) / 100 * 1000*1000*1000*1000/(workloadsArrayLocal[workloadItem].sizeAvgObj * 1024) * sizingConstraints.expectedAverageEntrySizeInObjectIndexInBytes * workloadsArrayLocal[workloadItem].selectorRGWLifecycleNumVersions * workloadsArrayLocal[workloadItem].reqNumReplica / workloadsArrayLocal[workloadItem].sumNumberDC
        ///////     }
        /////// }
        
        // calculate the local required index capacity (in this DC) for this workload (in TB) 
        //    => #DC=1 requires that all replica reside in this actual DC and should be the default number, 
        //    => #DC>1 would apply the replica number to the index as well.
        if (workloadsArrayLocal[workloadItem].sumNumberDC === 1) {
          localDCObjectIndexCapacity = workloadsArrayLocal[workloadItem.workload].reqCapacityNet * 1000*1000*1000*1000/(workloadsArrayLocal[workloadItem].sizeAvgObj * 1024) * sizingConstraints.expectedAverageEntrySizeInObjectIndexInBytes / 1024/1024/1024/1024 * workloadsArrayLocal[workloadItem].selectorRGWLifecycleNumVersions * sizingConstraints.requiredNumberOfReplicaForObjectIndex / workloadsArrayLocal[workloadItem].sumNumberDC
        }
        else {
          localDCObjectIndexCapacity = workloadsArrayLocal[workloadItem.workload].reqCapacityNet * 1000*1000*1000*1000/(workloadsArrayLocal[workloadItem].sizeAvgObj * 1024) * sizingConstraints.expectedAverageEntrySizeInObjectIndexInBytes / 1024/1024/1024/1024 * workloadsArrayLocal[workloadItem].selectorRGWLifecycleNumVersions * workloadsArrayLocal[workloadItem].reqNumReplica / workloadsArrayLocal[workloadItem].sumNumberDC
        }

        // Determine desired configuration for object index and add capacity to where needed.
        if (workloadsArrayLocal[workloadItem].selectorRGWIndexDedicatedFlashPool === true) {
          // if this is set it's for both HDD and flash based portions of the worklod - it's always going to the separate index pool and we need to collect how much capacity is needed
          // for this pool. The amount needed for raw will be already calculated by this because we'll apply the required replication and the number of DCs used for the workload.
          // The media type would be NVMe6 .
          localDCDedicatedObjectIndexCapacity += localDCObjectIndexCapacity
        }
        else {
          // There is no general desire for all portions to use a dedicated index pool. HDD would require a hybrid config and would need to add the capacity to the RocksDB space.
          // Depending on the SSD/NVMe configuration, a separate space might be needed for the data portion or on a dedicated media for RocksDB.
          if (workloadsArrayLocal[workloadItem].selectorDedicatedNVMe === true) {
            // For both HDD and flash: reserve additional space on dedicated NVMe (types 4 and 5)
            localDCRequiredIndexCapacityOnNVMe4 += localDCObjectIndexCapacity * (100 - workloadsArrayLocal[workloadItem].reqFlashPercent) / 100
            localDCRequiredIndexCapacityOnNVMe5 += localDCObjectIndexCapacity * workloadsArrayLocal[workloadItem].reqFlashPercent / 100
          }
          else {
            // For HDD, reserve additional capacity still on dedicated NVMe type 4
            localDCRequiredIndexCapacityOnNVMe4 += localDCObjectIndexCapacity * (100 - workloadsArrayLocal[workloadItem].reqFlashPercent) / 100
            localSSDAddCapacityWithOutDedicatedRocksDB += localDCObjectIndexCapacity * workloadsArrayLocal[workloadItem].reqFlashPercent / 100
          }
        }
                    
        // Determine the need of RGW dedicated cache and sum up a dedicated media per workload and minNumber of instances for RGW per workload
        if (workloadsArrayLocal[workloadItem].selectorRGWCache === true) {
          localDCNumberOfRGWCacheMedia += minNumberOfInstancesRoleRGW
        }

        // Apply corrections to RGW use cases based on avg object size   ===> This might need to go prior to calculating the HDD and assigning it in top of the function
        // Both values in TB. Since the value of gross capacity for the workload is not reflecting the capacity distribution across DCs, the number of DCs in use for the workload needs to be 
        //   taken into account, since this here is reflecting the actual needed capacity on the media inside a specific DC - for all individual workloads.
        localWorkloadCorrectionForUnalignedObjectsHDD = (((workloadsArrayLocal[workloadItem].sizeAvgObj*1024) % sizingConstraints.fixedMinAllocSizeOnMediaHDD) / workloadsArrayLocal[workloadItem].sizeAvgObj*1024) * workloadsArrayLocal[workloadItem].reqCapacityGrossHDD / workloadsArrayLocal[workloadItem].sumNumberDC
        localDCCorrectionForUnalignedObjectsHDD += localWorkloadCorrectionForUnalignedObjectsHDD
        // for flash: distinguish between normal and dedicated RocksDB media
        localWorkloadCorrectionForUnalignedObjectsSSD = (((workloadsArrayLocal[workloadItem].sizeAvgObj*1024) % sizingConstraints.fixedMinAllocSizeOnMediaSSD) / workloadsArrayLocal[workloadItem].sizeAvgObj*1024) * workloadsArrayLocal[workloadItem].reqCapacityGrossSSD / workloadsArrayLocal[workloadItem].sumNumberDC
        if (workloadsArrayLocal[workloadItem].selectorDedicatedNVMe === true) {
          localDCCorrectionForUnalignedObjectsSSDWithDedicatedNVMe += localWorkloadCorrectionForUnalignedObjectsSSD
        } else {
          localDCCorrectionForUnalignedObjectsSSDWithoutDedicatedNVMe += localWorkloadCorrectionForUnalignedObjectsSSD
        }
        /// All should be done here for specifics of RGW workloads.
      }      
      
      // CephFS workloads
      if (workloadsArrayLocal[workloadItem].selectorArrayDC[dcItem] === true && workloadsArrayLocal[workloadItem].useCase === "filedata" ) { 
        // Apply corrections to cephfs use cases based on avg object size
        // Both values in TB. Since the value of gross capacity for the workload is not reflecting the capacity distribution across DCs, the number of DCs in use for the workload needs to be 
        //   taken into account, since this here is reflecting the actual needed capacity on the media inside a specific DC - for all individual workloads.
        localWorkloadCorrectionForUnalignedObjectsHDD = (((workloadsArrayLocal[workloadItem].sizeAvgFile*1024) % sizingConstraints.fixedMinAllocSizeOnMediaHDD) / workloadsArrayLocal[workloadItem].sizeAvgFile*1024) * workloadsArrayLocal[workloadItem].reqCapacityGrossHDD / workloadsArrayLocal[workloadItem].sumNumberDC
        localDCCorrectionForUnalignedObjectsHDD += localWorkloadCorrectionForUnalignedObjectsHDD
        localWorkloadCorrectionForUnalignedObjectsSSD = (((workloadsArrayLocal[workloadItem].sizeAvgObj*1024) % sizingConstraints.fixedMinAllocSizeOnMediaSSD) / workloadsArrayLocal[workloadItem].sizeAvgFile*1024) * workloadsArrayLocal[workloadItem].reqCapacityGrossSSD / workloadsArrayLocal[workloadItem].sumNumberDC
        if (workloadsArrayLocal[workloadItem].selectorDedicatedNVMe === true) {
          localDCCorrectionForUnalignedObjectsSSDWithDedicatedNVMe += localWorkloadCorrectionForUnalignedObjectsSSD
        } else {
          localDCCorrectionForUnalignedObjectsSSDWithoutDedicatedNVMe += localWorkloadCorrectionForUnalignedObjectsSSD
        }
      }

      // RocksDB size must be calculated for any case: based on raw capacity needed per for the workload in the DC plus the correction for unaligned data or data portions - then decide where this additional
      //   capacity should go to: either dedicated media or the block device (for flash storage)
      localWorkloadRocksDBSizeHDD = workloadsArrayLocal[workloadItem].reqCapacityGrossHDD * workloadsArrayLocal[workloadItem].rocksDBSpaceInPercent / 100 + localWorkloadCorrectionForUnalignedObjectsHDD
      localDCRocksDBSizeHDD += localWorkloadRocksDBSizeHDD
      // for flash: distinguish between normal and dedicated RocksDB media - also assign here the requeired SSD capacity to one of the two groups
      // of dedicated vs non-dedicated media for RocksDB
      if (workloadsArrayLocal[workloadItem].selectorDedicatedNVMe === true) {
        localWorkloadRocksDBSizeSSDWithDedicatedNVMe = workloadsArrayLocal[workloadItem].reqCapacityGrossSSD * workloadsArrayLocal[workloadItem].rocksDBSpaceInPercent / 100 + localWorkloadCorrectionForUnalignedObjectsSSD
        localDCRocksDBSizeSSDWithDedicatedNVMe += localWorkloadRocksDBSizeSSDWithDedicatedNVMe
        localSSDCapacityWithDedicatedRocksDB += workloadsArrayLocal[workloadItem].reqCapacityGrossSSD
      }
      else {
        localWorkloadRocksDBSizeSSDWithoutDedicatedNVMe = workloadsArrayLocal[workloadItem].reqCapacityGrossSSD * workloadsArrayLocal[workloadItem].rocksDBSpaceInPercent / 100 + localWorkloadCorrectionForUnalignedObjectsSSD
        localDCRocksDBSizeSSDWithoutDedicatedNVMe += localWorkloadRocksDBSizeSSDWithoutDedicatedNVMe
        localSSDCapacityWithoutDedicatedRocksDB += workloadsArrayLocal[workloadItem].reqCapacityGrossSSD
      }
      
    }
    
    
    /// The specific size of media should come from a specific chassisConfig.
    // Media for dedicated index pool in DC
    dcConfigArrayLocal[dcItem].numberOfNVMe6Needed = Math.round(localDCDedicatedObjectIndexCapacity / chassisArrayLocal[actualChassisID].sizeNVMe6)

    // Media for dedicated RocksDB media for HDD
    dcConfigArrayLocal[dcItem].numberOfNVMe4Needed = Math.round((localDCRocksDBSizeHDD + localDCRequiredIndexCapacityOnNVMe4) / chassisArrayLocal[actualChassisID].sizeNVMe4)

    // Two different kinds of RocksDB capacity: with and withiout dedicated - with dedicated, there must be a different kind of media
    // for hosting the dedicated RocksDB: NVMe5; 
    // Note: the capacity of localDCCorrectionForUnalignedObjectsSSDWithDedicatedNVMe is not changing the RocksDB capacity.
    dcConfigArrayLocal[dcItem].numberOfNVMe5Needed = Math.round((localDCRocksDBSizeSSDWithDedicatedNVMe +  localDCRequiredIndexCapacityOnNVMe5) / chassisArrayLocal[actualChassisID].sizeNVMe5)

    // RGW cache media are dedicated and counted as they are
    dcConfigArrayLocal[dcItem].numberOfNVMe2Needed = localDCNumberOfRGWCacheMedia

    ////// HERE HERE HERE

    //// NOTE NOTE: we'll need to adjust the raw device capacity for any configuration by the correction factor of wasted space for objects and files if the avg object 
    ////            or file size is way off the min_alloc_size for the media. This should be done for replica and EC specifically !!!!
    ////            Way off means nothing specific but would be everything not aligning with min_alloc_size - even for small deviations, we can simply take it and don't need to 
    ////            distinguish between 'way off' and 'nearly matching'.
    
    dcConfigArrayLocal[dcItem].numberOfHDDNeeded =  Math.round((dcConfigArrayLocal[dcItem].capacityNeededForHDD + localCorrectionForUnalignedObjectsHDD) / chassisArrayLocal[actualChassisID].sizeHDD1)
    ////  In addition, the additional capacity for placing the RocksDB on any media used for block must be added to the number of media required - for kinds of flash.
    dcConfigArrayLocal[dcItem].numberOfSSDNeeded =  localNumberOfSSDNeededDedicatedRocksDB = Math.round((localSSDCapacityWithDedicatedRocksDB + localDCCorrectionForUnalignedObjectsSSDWithDedicatedNVMe) / chassisArrayLocal[actualChassisID].sizeSSD1)
    dcConfigArrayLocal[dcItem].numberOfSSDNeeded += localNumberOfSSDNeededNonDedicatedRocksDB = Math.round((localSSDCapacityWithoutDedicatedRocksDB + localDCRocksDBSizeSSDWithoutDedicatedNVMe + localDCCorrectionForUnalignedObjectsSSDWithoutDedicatedNVMe) / chassisArrayLocal[actualChassisID].sizeSSD1)
    
    // determine the number of dedicated WAL devices for SSD (aka previously known as Optanes)
    if (chassisArrayLocal[actualChassisID].useOptane1 === true) {
      let interrimOptaneNumberPerRatioDedicated = 0
      let interrimOptaneNumberPerCapacityDedicated = 0
      let interrimOptaneNumberPerRatioNonDedicatedRocksDB = 0
      let interrimOptaneNumberPerCapacityNonDedicatedRocksDB = 0
      interrimOptaneNumberPerRatioDedicated = Math.round(localNumberOfSSDNeededDedicatedRocksDB / chassisArrayLocal[actualChassisID].ssdToOptane)
      interrimOptaneNumberPerCapacityDedicated = Math.round(localNumberOfSSDNeededDedicatedRocksDB * sizingConstraints.sizeOfWALOnNVMeInGB / chassisArrayLocal[actualChassisID].sizeOptane1)
      interrimOptaneNumberPerRatioNonDedicatedRocksDB = Math.round(localNumberOfSSDNeededNonDedicatedRocksDB / chassisArrayLocal[actualChassisID].ssdToOptane)
      interrimOptaneNumberPerCapacityNonDedicatedRocksDB = Math.round(localNumberOfSSDNeededNonDedicatedRocksDB * sizingConstraints.sizeOfWALOnNVMeInGB / chassisArrayLocal[actualChassisID].sizeOptane1)
      // The higher number of devices as per either the matching number of devices per fronted flash device
      // or per capacity provided per device - first for flash devices with dedicated RocksDB
      if (interrimOptaneNumberPerRatioDedicated >= interrimOptaneNumberPerCapacityDedicated) {
        dcConfigArrayLocal[dcItem].numberOfNVMe3Needed = interrimOptaneNumberPerRatioDedicated
      }
      else {
        dcConfigArrayLocal[dcItem].numberOfNVMe3Needed = interrimOptaneNumberPerCapacityDedicated
      }
      // ... and then add the number needed for flash devices without dedicated RocksDB
      if (interrimOptaneNumberPerRatioNonDedicated >= interrimOptaneNumberPerCapacityNonDedicated) {
        dcConfigArrayLocal[dcItem].numberOfNVMe3Needed += interrimOptaneNumberPerRatioNonDedicated
      }
      else {
        dcConfigArrayLocal[dcItem].numberOfNVMe3Needed += interrimOptaneNumberPerCapacityNonDedicated
      }
    }
    // This should now have all media covered for this DC.
  }
}


let resultDCConfig = []
for (let cfgItem; cfgItem < ${Object.keys(chassisArray).length}; cfgItem++) {
  const newResult = new DCConfig
  resultDCConfig.push(newResult)
}
const resultsDCConfigDetermineNumberOfMediaRequired = function (generalValues, workloadsArrayLocal, sizingConstraints, dcConfigArrayLocal, chassisArrayLocal, resultDCConfigLocal) {
  for (let resultConfig; resultConfig < resultDCConfigLocal; resultConfig++) {
    console.log(`resultsDCConfigDetermineNumberOfMediaRequired(): working on config ${resultConfig}`)
    dcConfigDetermineNumberOfMediaRequired(generalValues, workloadsArrayLocal, sizingConstraints, dcConfigArrayLocal, chassisArrayLocal, resultConfig, resultDCConfigLocal)
  }
}

resultsDCConfigDetermineNumberOfMediaRequired(generalValues, workloadsArray, sizingConstraints, dcConfigArray, chassisArray, resultDCConfig)


