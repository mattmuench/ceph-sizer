class GeneralValues {
    constructor (
        desiredCapacityInTiB,
        desiredCapacityInTB,
        // Enable cell labels by setting globalDebug to true
        globalDebug,
        // All tables will show this number of configs - global setting (might become configurable eventually)
        numberOfConfigsPossible,
        // Number of workloads 
        numberOfWorkloadsPossible,
        // Number of DCs possible (and will be displayed in the detailed configs -- NOT YET: dynamic number of DCs in workloads)
        numberOfDCsPossible,
        // Number of DCs actually in use for all workloads
        numberOfDCsInUse,
        // Similar or different config per DC is desired ?
        desiredSimilarConfig

    )
    {
        this.desiredCapacityInTiB = desiredCapacityInTiB
        this.desiredCapacityInTB = desiredCapacityInTB
        this.globalDebug = false
        this.numberOfConfigsPossible = 8
        this.numberOfWorkloadsPossible = 8
        this.numberOfDCsPossible = 8
        this.desiredSimilarConfig = 1
        this.numberOfDCsInUse = 0
    }
    convertTiBIntoTB(inputCapacityInTiB) {
        this.desiredCapacityInTB = inputCapacityInTiB * 1024/1000 * 1024/1000 * 1024/1000 * 1024/1000
    }
}

export default GeneralValues;