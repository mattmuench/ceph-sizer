class DCConfig {
    constructor (
        DCID,
        capacityNeededForSSD,   // H41
        capacityNeededForHDD,   // H42
        capacityNeededForNVMe,  // no yet there
        numberOfLocalScaleoutInstances, // C41
        numberOfLocalSpecialInstances, // E41
        
        numberOfServersNeededAllInstances, // T41
        numberOfServersNeededMonInstances, //S41
        numberOfServersNeededForReplicaInSameDC, // R41
        numberOfServersNeededBasedOnChassisConfig, // Q41
        numberOfWorkloadsInDC, // D41

        numberOfHDDNeeded, // J41
        numberOfSSDNeeded, // J42
        numberOfNVMe1Needed, // M41 - for data
        
        numberOfNVMe2Needed, // N41 - for RGW dedicated cache (distinct per use case)
        numberOfNVMe3Needed, // U41 - "Optanes"
        numberOfNVMe4Needed, // none yet => RocksDB HDD
        numberOfNVMe5Needed, // none yet => RocksDB SSD
        numberOfNVMe6Needed, // none yet => RGW index data
        
        numberOfCoresNeeded, // V41
        memNeededPerServer, // W41

        constraintsBasedOnCores, // X41
        constraintsBasedOnMem, // X41
        constraintsBasedOnNothing, // X41
        constraintsBasedOnAll, // X41

        resultingNumberOfServers, // Y41
        resultingNumberOfCores, // Z41
        resultingMem, // AA41
        resultingNumberOfNVMe1, // AB41 (unused yet)
        resultingNumberOfSSD, // AC41
        resultingNumberOfHDD, // AD41
        resultingNumberOfNVMe2, // AE41
        resultingNumberOfNVMe3, //AF41



        
    ) {
        this.DCID = 0
    }
}


export default DCConfig;